class AutosoukModelMakeFuzzyComparisonModule:
    def __init__(self,configurationLoader, moduleConfigurationFile, settings, item):
        print("autosock")
        pass