elasticSerachServerIP="localhost"
elasticSearchServerPort=9200
elasticSearchIndexName="propertyindexv5"
elasticSearchMasterIndexName="a_masterdata"
elasticSearchUsername="es_admin"
elasticSearchPassword="OhTedu7e"
elasticSearchAutoCompleteIndex= "a_autocomplete"
# mapping config
areaCategory = "area"
propertyTypeCategory = "propertyType"
paymentTypeCategory = "paymentType"
furnishingCategory ="furnishings"
mappingServiceUrl  ="http://localhost:8080/masterMapping/api/service/getmastervalue"
