"# My project's README" 
Actions having methods to clean data points (like convert to float, standardize longtitude)
Attribute having methods to extract attributes from response
building pipeline handles data saving and cleaning
email for email Gmail API
fuzzy modules to correct mismatched names of areas
mapping and mapping pipeline has files to correct names
parsers takes xml attributes and actions.